from .favoritos import Favoritos
